package com.hexaware.springcoredemo;

import org.springframework.stereotype.Component;

@Component
public class EmailService {
	
	private DataSource dataSource;
	
	public EmailService(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void sendemail() {
		String email=dataSource.returnConnection();
		System.out.println(email);
	}
	

}
