package com.hexaware.springcoredemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class PostGreSqlDataSource implements DataSource {

	@Override
	public String returnConnection() {
		return "PostGreSQL DataSource is Used";
		
	}

}
