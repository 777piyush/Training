package com.hexaware.springcoredemo;

public interface DataSource {
	
	String returnConnection();

}
