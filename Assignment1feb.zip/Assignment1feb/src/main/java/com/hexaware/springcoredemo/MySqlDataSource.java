package com.hexaware.springcoredemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component

public class MySqlDataSource implements DataSource {

	@Override
	public String returnConnection() {
		return "MySqlDataSource is used";
		
		
	}
	

}
