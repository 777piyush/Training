package com.hexaware.springcoredemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
@ComponentScan("com.hexaware.springcoredemo")
public class config {

}
