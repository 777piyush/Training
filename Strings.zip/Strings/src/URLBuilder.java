import java.util.HashMap;
import java.util.Map;

class URLBuilder {

    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParams;

    public URLBuilder() {
        queryParams = new HashMap<>();
    }

    public URLBuilder setProtocol(String protocol) {
        this.protocol = protocol;
        return this;
    }

    public URLBuilder setHost(String host) {
        this.host = host;
        return this;
    }

    public URLBuilder setPath(String path) {
        this.path = path;
        return this;
    }

    public URLBuilder addQueryParam(String key, String value) {
        queryParams.put(key, value);
        return this;
    }

    public String build() {
        StringBuilder urlBuilder = new StringBuilder();

        if (protocol != null) {
            urlBuilder.append(protocol).append("://");
        }

        if (host != null) {
            urlBuilder.append(host);
        }

        if (path != null) {
            urlBuilder.append("/").append(path);
        }

        if (!queryParams.isEmpty()) {
            urlBuilder.append("?");
            queryParams.forEach((key, value) -> urlBuilder.append(key).append("=").append(value).append("&"));
            // Remove the trailing "&"
            urlBuilder.setLength(urlBuilder.length() - 1);
        }

        return urlBuilder.toString();
    }

    public static void main(String[] args) {
        URLBuilder urlBuilder = new URLBuilder()
                .setProtocol("https")
                .setHost("www.example.com")
                .setPath("path/to/resource")
                .addQueryParam("param1", "value1")
                .addQueryParam("param2", "value2");

        String constructedURL = urlBuilder.build();
        System.out.println("Constructed URL: " + constructedURL);
    }
}