/*
 * Create a class called StringSearchEngine that allows users to search for a specific pattern or substring in a given text. 
 * The class should have methods for:
 * Finding all occurrences of a substring.
 * return index of the matched substrings in the original text.
 */

import java.util.ArrayList;
import java.util.List;

public class StringSearchEngine {

    private String text;

    public StringSearchEngine(String text) {
        this.text = text;
    }

    public List<Integer> findAllOccurrences(String substring) {
        List<Integer> occurrences = new ArrayList<>();
        int index = text.indexOf(substring);

        while (index != -1) {
            occurrences.add(index);
            index = text.indexOf(substring, index + 1);
        }

        return occurrences;
    }

    public int findFirstOccurrence(String substring) {
        return text.indexOf(substring);
    }

    public static void main(String[] args) {
        StringSearchEngine searchEngine = new StringSearchEngine("This is a sample text. The sample text is used for searching.");

        String substringToFind = "sample";
        List<Integer> allOccurrences = searchEngine.findAllOccurrences(substringToFind);
        int firstOccurrence = searchEngine.findFirstOccurrence(substringToFind);

        System.out.println("All occurrences of '" + substringToFind + "': " + allOccurrences);
        System.out.println("First occurrence of '" + substringToFind + "': " + firstOccurrence);
    }
}

